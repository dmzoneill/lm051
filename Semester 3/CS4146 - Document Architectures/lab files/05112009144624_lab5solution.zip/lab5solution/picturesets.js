///////////////////////////////////////////////////////////////////
// CS4146 Document Architectures

function listPictureSets(xSets) {
  for(var i = 0; i < xSets.length; i++) make_request(xSets[i]);
}

function make_request(filename)
{
    var req = false;
    
    if (window.ActiveXObject) { //IE
        req = new ActiveXObject("Microsoft.XMLHTTP");
    }
    else if (window.XMLHttpRequest) { //other browsers
        req = new XMLHttpRequest();
    }
    
    req.open('GET', filename, true);
    req.onreadystatechange = function() {
        if (req.readyState == 4) {
            var xmlDoc = req.responseXML;
            var setTitle = xmlDoc.getElementsByTagName('title').item(0).firstChild.nodeValue;
            var textdata = document.createTextNode(setTitle); 
            var newParagraph = document.createElement('p');
            newParagraph.appendChild(textdata);
            document.getElementById('title_container').appendChild(newParagraph);           
        }
    }
    req.send(null);
}