///////////////////////////////////////////////////////////////////
// CS4146 Document Architecture, Lab 4
// JavaScript functions for manipulating sets of pictures.
// This version requires MS Internet Explorer 5.5+
//


///////////////////////////////////////////////////////////////////
// popItUp
//
// Loads a picture into a pop-up window
//
// picture_location: the URI of the picture
// dimensions: a string of the form 'width=W, height=H' 
// where W and H are the width and the height 
// of the picture respectively

function popItUp(picture_location, dimensions) 
{
  newwindow = window.open('','_blank', dimensions);
  newwindow.document.write('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html14/strict.dtd">');
  newwindow.document.write('<html>');
  newwindow.document.write('<head><title>Popup</title><style type="text/css">body { margin: 0; }</style></head>');
  newwindow.document.write('<body><img src="' + picture_location + '"/></body>')
  newwindow.document.write('</html>');
}


//////////////////////////////////////////////////////////////////
// listPictureSets
//
// Creates the list of links to picture sets in the webpage
//
// xSets: an array of names of XML files; each file conforms to
// http://www.csis.ul.ie/modules/cs4146/lab04/example/pictureset.dtd

function listPictureSets(xSets)
{
  for( i = 0; i < xSets.length; i++) {
    var xmlDoc = new ActiveXObject('Microsoft.XMLDOM');
    xmlDoc.load(xSets[i]);
    
    var RootsChildren = xmlDoc.documentElement.childNodes;
    var setTitle = RootsChildren.item(0).firstChild.nodeValue;
    var textdata = document.createTextNode(setTitle);

    var newLink = document.createElement('a');
    newLink.setAttribute('href', 'javascript:displayPictureSet(\'' + xSets[i] + '\')');
    newLink.appendChild(textdata);

    var newParagraph = document.createElement('p');
    newParagraph.appendChild(newLink);

    document.getElementById('links_container').appendChild(newParagraph);
  }
}


//////////////////////////////////////////////////////////////////
// displayPictureGallery
//
// Displays a table with the thumbnails of pictures 
// described in the XML file xSet that conforms to
// http://www.csis.ul.ie/modules/cs4146/lab04/example/pictureset.dtd
//
// xSet: the path (URI) of the XML file

function displayPictureSet(xSet) 
{
  var tn_width = 100;
  var tn_height = 60;
  var tn_per_row = 3;

  var xmlDoc = new ActiveXObject('Microsoft.XMLDOM');
  xmlDoc.load(xSet);

  pictures = xmlDoc.documentElement.childNodes;

  // display the title of the picture set
  var setTitle = document.createTextNode(pictures.item(0).firstChild.nodeValue);

  titleContainer = document.getElementById('title_container');  

  //remove previous title
  while (titleContainer.hasChildNodes()) 
    titleContainer.removeChild(titleContainer.firstChild);

  //display the new title
  titleContainer.appendChild(setTitle);

  // display the thumbnails
  var tnTableBody = document.createElement('tbody');

  var i = 1;
  for ( var curNode = pictures.item(1); curNode != null; curNode = curNode.nextSibling, i++) {
    if (i % tn_per_row == 1) {
      var curRow = document.createElement('tr');
    }

    var curCell = document.createElement('td');
    curCell.setAttribute('width', tn_width);

    var source = curNode.firstChild;
    var sourceLocation = source.getAttribute('location');
    var sourceHeight = source.getAttribute('height');
    var sourceWidth = source.getAttribute('width');

    var curLink = document.createElement('a');
    curLink.setAttribute('href', 'javascript:popItUp(\'' + sourceLocation + '\', \'width=' + sourceWidth + ',height=' + sourceHeight + '\')');

    var tn_location;
    if (curNode.childNodes.length == 2)
      // no thumbnail specified in the XML document
      tn_location = source.getAttribute('location');  
    else
      // thumbnail specified in the XML document
      tn_location = source.nextSibling.getAttribute('location');
					
    var curImg = document.createElement('img');
    curImg.setAttribute('src', tn_location);
    curImg.setAttribute('width', tn_width);
    curImg.setAttribute('height', tn_height);

    curLink.appendChild(curImg);
    curCell.appendChild(curLink);

    /////////////////////////
    //TASK B SOLUTION START
    // add some code here
    //TASK B SOLUTION END
    //////////////////////////

    curRow.appendChild(curCell);
    
    if ( (i % tn_per_row == 0) || (i == pictures.length - 1) ) 
      tnTableBody.appendChild(curRow);
  }

  thumbnailsContainer = document.getElementById('thumbnails_container');  
  while (thumbnailsContainer.hasChildNodes()) 
    thumbnailsContainer.removeChild(thumbnailsContainer.firstChild);
  thumbnailsContainer.appendChild(tnTableBody);
}
