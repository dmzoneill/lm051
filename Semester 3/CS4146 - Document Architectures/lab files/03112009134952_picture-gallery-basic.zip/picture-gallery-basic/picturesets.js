///////////////////////////////////////////////////////////////////
// CS4146 Document Architectures
// JavaScript functions for manipulating sets of pictures.
// This version requires MS Internet Explorer 5.5+

function listPictureSets(xSets)
{
  for( i = 0; i < xSets.length; i++) {
    var xmlDoc = new ActiveXObject('Microsoft.XMLDOM');
    xmlDoc.load(xSets[i]);

    var setTitle = xmlDoc.getElementsByTagName('title').item(0).firstChild.nodeValue;
    var textdata = document.createTextNode(setTitle);

    var newParagraph = document.createElement('p');
    newParagraph.appendChild(textdata);

    document.getElementById('title_container').appendChild(newParagraph);
  }
}