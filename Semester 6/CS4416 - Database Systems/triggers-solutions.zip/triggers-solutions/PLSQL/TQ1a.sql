CREATE OR REPLACE TRIGGER TQ1a
AFTER INSERT ON laptop 
REFERENCING NEW AS tup 
FOR EACH ROW 
BEGIN
  DECLARE v_count NUMBER(5);
  BEGIN
    SELECT count(*) INTO v_count FROM product WHERE model = :tup.model;
    IF v_count = 0 THEN
      INSERT INTO product VALUES(NULL, :tup.model, 'laptop');
    END IF;
  END;
END;
.
run;