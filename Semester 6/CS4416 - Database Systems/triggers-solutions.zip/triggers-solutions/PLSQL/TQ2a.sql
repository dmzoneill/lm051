CREATE OR REPLACE TRIGGER TQ2a
AFTER UPDATE ON product 
FOR EACH ROW
BEGIN
  DECLARE product_type product.type%TYPE;
  BEGIN
    SELECT type INTO product_type FROM product WHERE model = :new.model;
    IF :new.model <> :old.model THEN
      IF product_type = 'pc' THEN
        UPDATE pc SET model = :new.model WHERE model = :old.model;
      ELSE 
        IF product_type = 'laptop' THEN
          UPDATE laptop SET model = :new.model WHERE model = :old.model;
        END IF;
      END IF;
    END IF;
  END;
END;
.
run;