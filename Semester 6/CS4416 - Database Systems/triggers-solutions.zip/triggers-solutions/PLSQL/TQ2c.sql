CREATE OR REPLACE TRIGGER TQ2c1
AFTER UPDATE ON product 
FOR EACH ROW
WHEN ((new.model <> old.model) AND (new.type = 'pc'))
BEGIN
  UPDATE pc SET model = :new.model WHERE model = :old.model;
END;
.
run;

CREATE OR REPLACE TRIGGER TQ2c2
AFTER UPDATE ON product 
FOR EACH ROW
WHEN ((new.model <> old.model) AND (new.type = 'laptop'))
BEGIN
  UPDATE laptop SET model = :new.model WHERE model = :old.model;
END;
.
run;