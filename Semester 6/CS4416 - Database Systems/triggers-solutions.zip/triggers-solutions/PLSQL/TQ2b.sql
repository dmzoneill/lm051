CREATE OR REPLACE TRIGGER TQ2b
AFTER UPDATE ON product 
FOR EACH ROW
WHEN (new.model <> old.model)
BEGIN
  DECLARE product_type product.type%TYPE;
  BEGIN
    SELECT type into product_type FROM product WHERE model = :new.model;
    IF product_type = 'pc' THEN
       UPDATE pc SET model = :new.model WHERE model = :old.model;
    ELSE
       IF product_type = 'laptop' THEN
         UPDATE laptop SET model = :new.model WHERE model = :old.model;
       END IF;
    END IF;
  END;
END;
.
run;