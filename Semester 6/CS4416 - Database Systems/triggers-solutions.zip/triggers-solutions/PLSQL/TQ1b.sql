CREATE OR REPLACE TRIGGER TQ1b
AFTER INSERT ON laptop
FOR EACH ROW 
BEGIN
  DECLARE v_count NUMBER(5);
  BEGIN
    SELECT count(*) INTO v_count FROM product WHERE model = :new.model;
    IF v_count = 0 THEN
      INSERT INTO product VALUES(NULL, :new.model, 'laptop');
    END IF;
  END;
END;
.
run;