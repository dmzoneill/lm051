select maker
from product
where model in (select model
                from laptop
                where hd >= 100);
