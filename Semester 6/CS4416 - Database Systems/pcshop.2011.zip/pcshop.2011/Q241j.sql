select A.maker
from product A, pc B
where A.type = 'pc' and
      A.model = B.model
group by maker
having count(distinct speed) >= 3;
