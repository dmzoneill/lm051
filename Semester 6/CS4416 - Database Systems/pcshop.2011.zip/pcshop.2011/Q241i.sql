create view product_pc as 
(
  select A.maker, A.model, B.speed
  from product A, pc B
  where A.type = 'pc' and
        A.model = B.model
);

create view product_laptop as 
(
  select A.maker, A.model, B.speed
  from product A, laptop B
  where A.type = 'laptop' and
        A.model = B.model
);

create view product_all as
(
  (select * from product_pc)
  union
  (select * from product_laptop)
);

select distinct maker
from product_all
where speed >= ALL(select speed
                   from product_all);

drop view product_all;

drop view product_laptop;

drop view product_pc;
