select A.model, B.model 
from pc A, pc B
where A.model < B.model and
      A.speed = B.speed and
      A.ram = B.ram;
