select model
from PC
where speed >= 3.00;
