create view A as (
  select model, price
  from pc
  where model in (select model from product where maker = 'B')
);

create view B as (
  select model, price
  from laptop
  where model in (select model from product where maker = 'B')
);

create view C as (
  select model, price
  from printer
  where model in (select model from product where maker = 'B')
);

(select * from A) union (select * from B) union (select * from C);

drop view C;

drop view B;

drop view A;

