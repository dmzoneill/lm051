select maker
from product
where type = 'pc'
group by maker
having count(distinct model) = 3;
