select model
from printer
where color = 'true' and type = 'laser';
