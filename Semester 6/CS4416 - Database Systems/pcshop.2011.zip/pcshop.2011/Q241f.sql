select distinct A.hd
from pc A, pc B
where A.hd = B.hd and A.model <> B.model;
