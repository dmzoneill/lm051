create view product_pc as 
(
  select maker, model, type
  from product
  where type = 'pc' and
        model in (select model
                  from pc
                  where speed >= 2.80)
);

create view product_laptop as 
(
  select maker, model, type
  from product
  where type = 'laptop' and
        model in (select model
                  from laptop
                  where speed >= 2.80)
);

create view product_all as
(
  (select * from product_pc)
  union
  (select * from product_laptop)
);

select distinct A.maker
from product_all A, product_all B
where A.maker = B.maker 
      and
      (
        ((A.model = B.model) and (A.type < B.type))
        or
	(A.model < B.model)
      );

drop view product_all;

drop view product_laptop;

drop view product_pc;
