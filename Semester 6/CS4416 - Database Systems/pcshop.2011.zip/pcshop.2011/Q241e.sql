(select maker from product where type = 'laptop')
minus
(select maker from product where type = 'pc'); 
